package com.example.videosource

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import org.jsoup.Jsoup
import java.net.URI
import java.util.concurrent.TimeUnit

enum class Kind(val label: String) {
    FILE("Video file"),
    STREAM("Stream playlist (.m3u8 / .mpd)"),
    PAGE("Page")
}

data class Candidate(
    val url: String,
    val kind: Kind,
    val mime: String? = null,
    val size: Long? = null,
    val note: String? = null
)

data class SourceInfo(
    val pageUrl: String,
    val title: String?,
    val site: String?,
    val author: String?,
    val canonical: String?,
    val thumbnail: String?,
    val candidates: List<Candidate>
)

/**
 * Looks at a link the way a browser would and reports where the video really lives:
 * redirects, og:video / <video> tags, JSON-LD, embedded players, canonical page, thumbnail.
 * Only uses what the site publicly serves. No login, DRM or signature bypassing.
 */
object SourceFinder {
    const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    private val VIDEO_EXT = listOf(".mp4", ".webm", ".mov", ".mkv", ".m4v", ".3gp")

    private val MEDIA_RE = Regex(
        """https?://[^\s"'<>\\]+?\.(?:mp4|webm|m3u8|mov|mkv|mpd)(?:\?[^\s"'<>\\]*)?""",
        RegexOption.IGNORE_CASE
    )

    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private class Probe(val finalUrl: String, val mime: String?, val size: Long?)

    fun resolve(input: String, referer: String? = null, depth: Int = 0): SourceInfo {
        val b = Request.Builder().url(input)
            .header("User-Agent", UA)
            .header("Accept-Language", "en-US,en;q=0.9")
        referer?.let { b.header("Referer", it) }

        return client.newCall(b.build()).execute().use { resp ->
            val finalUrl = resp.request.url.toString()
            val mime = resp.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase()
            val kind = classify(finalUrl, mime)

            if (kind == Kind.FILE || kind == Kind.STREAM) {
                // The link itself is already the media file.
                SourceInfo(
                    finalUrl, null, null, null, null, null,
                    listOf(Candidate(finalUrl, kind, mime, resp.header("Content-Length")?.toLongOrNull()))
                )
            } else {
                if (!resp.isSuccessful) error("HTTP ${resp.code} from ${resp.request.url.host}")
                parseHtml(resp.peekBody(3_000_000).string(), finalUrl, depth)
            }
        }
    }

    fun fetchBytes(url: String, referer: String?): ByteArray? = try {
        val b = Request.Builder().url(url).header("User-Agent", UA)
        referer?.let { b.header("Referer", it) }
        client.newCall(b.build()).execute().use {
            if (it.isSuccessful) it.peekBody(5_000_000).bytes() else null
        }
    } catch (e: Exception) {
        null
    }

    private fun classify(url: String, mime: String?): Kind? {
        val path = url.substringBefore('?').substringBefore('#').lowercase()
        return when {
            mime != null && mime.startsWith("video/") -> Kind.FILE
            mime != null && ("mpegurl" in mime || "dash+xml" in mime) -> Kind.STREAM
            path.endsWith(".m3u8") || path.endsWith(".mpd") -> Kind.STREAM
            (mime == null || mime.endsWith("octet-stream")) && VIDEO_EXT.any { path.endsWith(it) } -> Kind.FILE
            mime != null && mime.startsWith("text/html") -> Kind.PAGE
            else -> null
        }
    }

    /** Cheap request that returns headers only (asks for the first byte). */
    private fun probe(url: String, referer: String?): Probe? {
        return try {
            val b = Request.Builder().url(url)
                .header("User-Agent", UA)
                .header("Range", "bytes=0-0")
            referer?.let { b.header("Referer", it) }
            client.newCall(b.build()).execute().use { r ->
                if (!r.isSuccessful) {
                    null
                } else {
                    val mime = r.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase()
                    val size = if (r.code == 206) {
                        r.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                    } else {
                        r.header("Content-Length")?.toLongOrNull()
                    }
                    Probe(r.request.url.toString(), mime, size)
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseHtml(html: String, pageUrl: String, depth: Int): SourceInfo {
        val doc = Jsoup.parse(html, pageUrl)

        fun abs(raw: String?): String? {
            val r = raw?.trim().orEmpty()
            if (r.isEmpty() || r == "null") return null
            if (r.startsWith("http://") || r.startsWith("https://")) return r
            if (r.startsWith("//")) return "https:$r"
            return try {
                val u = URI(pageUrl).resolve(r).toString()
                if (u.startsWith("http")) u else null
            } catch (e: Exception) {
                null
            }
        }

        fun meta(vararg keys: String): String? = keys.firstNotNullOfOrNull { k ->
            doc.select("meta[property=\"$k\"],meta[name=\"$k\"],meta[itemprop=\"$k\"]")
                .firstOrNull()?.attr("content")?.trim()?.takeIf { it.isNotEmpty() }
        }

        val urls = LinkedHashSet<String>()
        fun add(raw: String?) {
            abs(raw)?.let { urls.add(it) }
        }

        // 1) Social/meta tags sites publish for link previews
        listOf(
            "og:video", "og:video:url", "og:video:secure_url",
            "twitter:player:stream", "contentUrl", "twitter:player"
        ).forEach { add(meta(it)) }

        // 2) Plain HTML5 video and download links
        doc.select("video[src], video source[src]").forEach { add(it.attr("src")) }
        doc.select("a[href]").forEach { a ->
            val h = a.attr("href")
            val p = h.substringBefore('?').lowercase()
            if (VIDEO_EXT.any { p.endsWith(it) }) add(h)
        }

        // 3) JSON-LD (schema.org VideoObject)
        var jsonAuthor: String? = null
        var jsonThumb: String? = null
        fun walk(n: Any?) {
            when (n) {
                is JSONArray -> for (i in 0 until n.length()) walk(n.opt(i))
                is JSONObject -> {
                    add(n.optString("contentUrl"))
                    add(n.optString("embedUrl"))
                    if (jsonAuthor == null) {
                        jsonAuthor = when (val a = n.opt("author")) {
                            is String -> a
                            is JSONObject -> a.optString("name")
                            is JSONArray -> a.optJSONObject(0)?.optString("name")
                            else -> null
                        }?.takeIf { it.isNotBlank() && it != "null" }
                    }
                    if (jsonThumb == null) {
                        jsonThumb = when (val t = n.opt("thumbnailUrl")) {
                            is String -> t
                            is JSONArray -> t.optString(0)
                            else -> null
                        }?.takeIf { it.isNotBlank() && it != "null" }
                    }
                    n.keys().forEach { walk(n.opt(it)) }
                }
            }
        }
        doc.select("script[type=application/ld+json]").forEach { s ->
            try {
                walk(JSONTokener(s.data()).nextValue())
            } catch (e: Exception) {
                // ignore malformed JSON-LD
            }
        }

        // 4) Media URLs sitting inside inline scripts / player config
        val cleaned = html.replace("\\/", "/").replace("\\u0026", "&")
            .replace("\\u002F", "/").replace("&amp;", "&")
        MEDIA_RE.findAll(cleaned).take(20).forEach { add(it.value) }

        // 5) Only if nothing else turned up: embedded iframes (a player page often hides the file)
        if (urls.isEmpty()) {
            doc.select("iframe[src]").take(3).forEach { add(it.attr("src")) }
        }

        val canonical = abs(doc.select("link[rel=canonical]").firstOrNull()?.attr("href"))
            ?: abs(meta("og:url"))

        val found = LinkedHashMap<String, Candidate>()
        if (canonical != null && canonical.trimEnd('/') != pageUrl.trimEnd('/')) {
            found[canonical] = Candidate(canonical, Kind.PAGE, note = "Canonical page (the site's declared original)")
        }

        for (u in urls.take(15)) {
            val p = probe(u, pageUrl)
            val finalUrl = p?.finalUrl ?: u
            val kind = classify(finalUrl, p?.mime) ?: continue
            if (kind == Kind.PAGE) {
                found.putIfAbsent(finalUrl, Candidate(finalUrl, Kind.PAGE, p?.mime, null, "Embedded player / source page"))
                if (depth < 1 && p != null) {
                    runCatching { resolve(finalUrl, pageUrl, depth + 1) }.getOrNull()
                        ?.candidates
                        ?.filter { it.kind != Kind.PAGE }
                        ?.forEach { found.putIfAbsent(it.url, it.copy(note = "Found inside embedded player")) }
                }
            } else {
                found.putIfAbsent(finalUrl, Candidate(finalUrl, kind, p?.mime, p?.size))
            }
        }

        val sorted = found.values.sortedWith(
            compareBy<Candidate>({ it.kind.ordinal }, { -(it.size ?: 0L) })
        )

        return SourceInfo(
            pageUrl = pageUrl,
            title = meta("og:title", "twitter:title") ?: doc.title().takeIf { it.isNotBlank() },
            site = meta("og:site_name") ?: runCatching { URI(pageUrl).host }.getOrNull(),
            author = jsonAuthor ?: meta("author", "article:author", "twitter:creator"),
            canonical = canonical,
            thumbnail = abs(meta("og:image", "og:image:url", "twitter:image") ?: jsonThumb),
            candidates = sorted
        )
    }
}
