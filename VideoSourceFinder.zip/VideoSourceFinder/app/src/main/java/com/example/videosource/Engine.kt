package com.example.videosource

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File
import java.net.URI

private class Ranked(val c: Candidate, val rank: Int, val h: Int)

/**
 * Wraps yt-dlp (free, open source), which knows how to pull the real media
 * address out of well over a thousand sites. It does not bypass DRM or logins.
 */
object Engine {
    @Volatile var ready = false
    @Volatile var initError: String? = null
    private val lock = Any()

    const val FMT_BEST = "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b"
    const val FMT_720 =
        "bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[height<=720][ext=mp4]/bv*[height<=720]+ba/b[height<=720]/b"
    const val FMT_AUDIO = "ba[ext=m4a]/ba/b"

    fun ensureInit(app: Application) {
        if (ready) return
        synchronized(lock) {
            if (ready) return
            try {
                YoutubeDL.getInstance().init(app)
                try {
                    FFmpeg.getInstance().init(app)
                } catch (e: Throwable) {
                    // merging video+audio will be unavailable, everything else still works
                }
                ready = true
                initError = null
            } catch (e: Throwable) {
                initError = friendly(e)
            }
        }
    }

    fun friendly(e: Throwable): String {
        val m = e.message ?: return e.javaClass.simpleName
        val line = m.lines().lastOrNull { it.contains("ERROR") } ?: m.lines().firstOrNull { it.isNotBlank() } ?: m
        return line.trim().take(300)
    }

    fun update(app: Application): String {
        ensureInit(app)
        if (!ready) return "Engine unavailable: ${initError ?: "unknown error"}"
        return try {
            val st = YoutubeDL.getInstance().updateYoutubeDL(app)
            "Update check done (${st ?: "already up to date"})"
        } catch (e: Throwable) {
            "Update failed: ${friendly(e)}"
        }
    }

    /** Ask yt-dlp what it knows about the link (no download). */
    fun info(app: Application, url: String): SourceInfo {
        ensureInit(app)
        if (!ready) error("Engine unavailable: ${initError ?: "unknown error"}")

        val req = YoutubeDLRequest(url)
        req.addOption("--dump-single-json")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "20")

        val out = YoutubeDL.getInstance().execute(req).out
        val a = out.indexOf('{')
        val b = out.lastIndexOf('}')
        if (a < 0 || b <= a) error("The engine returned no data")

        var j = JSONObject(out.substring(a, b + 1))
        if (j.optString("_type") == "playlist") {
            j = j.optJSONArray("entries")?.optJSONObject(0) ?: j
        }
        return parse(j, url)
    }

    /** Download with yt-dlp into [dir] and return the finished file. */
    fun download(app: Application, url: String, format: String, dir: File, audioOnly: Boolean): File {
        ensureInit(app)
        if (!ready) error("Engine unavailable: ${initError ?: "unknown error"}")
        dir.mkdirs()

        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        req.addOption("--no-mtime")
        req.addOption("--restrict-filenames")
        req.addOption("-N", "4")
        req.addOption("-f", format)
        if (!audioOnly) req.addOption("--merge-output-format", "mp4")
        req.addOption("-o", dir.absolutePath + "/%(title).80s-%(id).20s.%(ext)s")

        YoutubeDL.getInstance().execute(req)

        return dir.listFiles()
            ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.length() }
            ?: error("The download finished but no file was found")
    }

    private fun parse(j: JSONObject, input: String): SourceInfo {
        fun s(k: String): String? = j.optString(k, "").takeIf { it.isNotBlank() && it != "null" }

        val page = s("webpage_url") ?: input
        val author = s("uploader") ?: s("channel") ?: s("creator")
        val authorUrl = s("uploader_url") ?: s("channel_url")

        val ranked = mutableListOf<Ranked>()
        val fmts = j.optJSONArray("formats")
        if (fmts != null) {
            for (i in 0 until fmts.length()) {
                val f = fmts.optJSONObject(i) ?: continue
                fromFormat(f)?.let { ranked.add(it) }
            }
        }
        if (ranked.isEmpty()) fromFormat(j)?.let { ranked.add(it) }

        val cands = ranked
            .sortedWith(compareBy<Ranked>({ it.rank }, { -it.h }))
            .take(12)
            .map { it.c }
            .toMutableList()

        if (page.trimEnd('/') != input.trimEnd('/')) {
            cands.add(Candidate(page, Kind.PAGE, note = "Resolved original page"))
        }
        authorUrl?.let { cands.add(Candidate(it, Kind.PAGE, note = "Uploader / channel page")) }

        val details = mutableListOf<String>()
        s("upload_date")?.takeIf { it.length == 8 }?.let {
            details.add("Uploaded: ${it.substring(0, 4)}-${it.substring(4, 6)}-${it.substring(6)}")
        }
        val d = j.optDouble("duration", 0.0)
        if (d > 0) {
            val t = d.toInt()
            details.add(
                "Duration: " + if (t >= 3600) "%d:%02d:%02d".format(t / 3600, t % 3600 / 60, t % 60)
                else "%d:%02d".format(t / 60, t % 60)
            )
        }
        authorUrl?.let { details.add("Uploader link: $it") }

        return SourceInfo(
            pageUrl = page,
            title = s("title"),
            site = s("extractor_key") ?: runCatching { URI(page).host }.getOrNull(),
            author = author,
            canonical = page,
            thumbnail = s("thumbnail"),
            candidates = cands,
            engine = true,
            details = details
        )
    }

    private fun fromFormat(f: JSONObject): Ranked? {
        val u = f.optString("url", "")
        if (!u.startsWith("http")) return null

        val proto = f.optString("protocol", "https")
        val ext = f.optString("ext", "").takeIf { it.isNotBlank() && it != "null" }
        if (ext == "mhtml" || f.optString("format_note", "") == "storyboard") return null

        val isHls = proto.contains("m3u8")
        if (!isHls && proto != "https" && proto != "http") return null

        val hasV = f.optString("vcodec", "") != "none"
        val hasA = f.optString("acodec", "") != "none"
        val h = f.optInt("height", 0)
        val size = f.optLong("filesize", 0L).takeIf { it > 0 }
            ?: f.optLong("filesize_approx", 0L).takeIf { it > 0 }

        val headers = HashMap<String, String>()
        f.optJSONObject("http_headers")?.let { hj ->
            hj.keys().forEach { k -> headers[k] = hj.optString(k) }
        }

        val label = buildString {
            if (h > 0) append("${h}p • ")
            append(ext ?: "video")
            when {
                isHls -> append(" • HLS playlist")
                hasV && hasA -> {}
                hasV -> append(" • video only (no sound)")
                else -> append(" • audio only")
            }
        }

        val kind = if (isHls) Kind.STREAM else Kind.FILE
        val rank = when {
            isHls -> 3
            hasV && hasA -> 0
            hasV -> 1
            else -> 2
        }
        return Ranked(
            Candidate(u, kind, null, size, label, !isHls && hasA, headers, ext),
            rank,
            h
        )
    }
}
