package com.example.videosource

import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.text.format.Formatter
import android.view.View
import android.webkit.URLUtil
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var thumb: ImageView
    private lateinit var infoText: TextView
    private lateinit var searchBox: LinearLayout
    private lateinit var header: TextView
    private lateinit var results: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        thumb = findViewById(R.id.thumb)
        infoText = findViewById(R.id.infoText)
        searchBox = findViewById(R.id.searchBox)
        header = findViewById(R.id.header)
        results = findViewById(R.id.results)

        findViewById<Button>(R.id.findBtn).setOnClickListener { start(urlInput.text.toString()) }
        findViewById<Button>(R.id.pasteBtn).setOnClickListener { paste() }

        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            extractUrl(text)?.let { urlInput.setText(it); start(it) }
        }
    }

    private fun paste() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        urlInput.setText(extractUrl(t) ?: t)
    }

    private fun extractUrl(text: String): String? {
        Regex("""https?://\S+""").find(text)?.value
            ?.trimEnd('.', ',', ')', ']', '"', '\'')
            ?.let { return it }
        val t = text.trim()
        return if (t.contains('.') && !t.contains(' ')) "https://$t" else null
    }

    private fun start(raw: String) {
        val url = extractUrl(raw)
        if (url == null) {
            status.text = "Enter a link that starts with http:// or https://"
            return
        }
        results.removeAllViews()
        header.visibility = View.GONE
        searchBox.visibility = View.GONE
        thumb.visibility = View.GONE
        infoText.visibility = View.GONE
        progress.visibility = View.VISIBLE
        status.text = "Looking for the source…"

        thread {
            val r = runCatching { SourceFinder.resolve(url) }
            runOnUiThread {
                progress.visibility = View.GONE
                r.onSuccess { show(it) }
                    .onFailure { status.text = "Couldn't read that link: ${it.message ?: it.javaClass.simpleName}" }
            }
        }
    }

    private fun show(info: SourceInfo) {
        val files = info.candidates.count { it.kind == Kind.FILE }
        val streams = info.candidates.count { it.kind == Kind.STREAM }
        status.text = when {
            files > 0 -> "Found $files downloadable file(s)."
            streams > 0 -> "Found a stream playlist but no single file. Copy the link into a stream-capable tool such as yt-dlp or ffmpeg."
            else -> "No direct video file in this page's public code. Many big platforms deliver video through protected players; see the README."
        }

        infoText.text = buildString {
            info.title?.let { appendLine(it) }
            val meta = listOfNotNull(info.site?.let { "Site: $it" }, info.author?.let { "Author: $it" })
            if (meta.isNotEmpty()) appendLine(meta.joinToString("  |  "))
            append("Page: ${info.pageUrl}")
        }
        infoText.visibility = View.VISIBLE

        info.thumbnail?.let { t ->
            searchBox.visibility = View.VISIBLE
            bind(R.id.lensBtn, "https://lens.google.com/uploadbyurl?url=${Uri.encode(t)}")
            bind(R.id.tineyeBtn, "https://tineye.com/search?url=${Uri.encode(t)}")
            bind(R.id.yandexBtn, "https://yandex.com/images/search?rpt=imageview&url=${Uri.encode(t)}")
            loadThumb(t, info.pageUrl)
        }

        if (info.candidates.isNotEmpty()) header.visibility = View.VISIBLE
        info.candidates.forEach { c ->
            val row = layoutInflater.inflate(R.layout.item_candidate, results, false)
            row.findViewById<TextView>(R.id.label).text = buildString {
                append(c.note ?: c.kind.label)
                c.size?.let { append(" • ").append(Formatter.formatShortFileSize(this@MainActivity, it)) }
                c.mime?.let { append(" • ").append(it) }
            }
            row.findViewById<TextView>(R.id.urlText).text = c.url
            row.findViewById<Button>(R.id.dlBtn).apply {
                visibility = if (c.kind == Kind.FILE) View.VISIBLE else View.GONE
                setOnClickListener { download(c, info.pageUrl) }
            }
            row.findViewById<Button>(R.id.copyBtn).setOnClickListener {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("url", c.url))
                toast("Link copied")
            }
            row.findViewById<Button>(R.id.openBtn).setOnClickListener { openUrl(c.url) }
            results.addView(row)
        }
    }

    private fun bind(id: Int, url: String) {
        findViewById<Button>(id).setOnClickListener { openUrl(url) }
    }

    private fun loadThumb(url: String, referer: String) {
        thread {
            val bytes = SourceFinder.fetchBytes(url, referer) ?: return@thread
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@thread
            runOnUiThread {
                thumb.setImageBitmap(bmp)
                thumb.visibility = View.VISIBLE
            }
        }
    }

    private fun download(c: Candidate, referer: String) {
        try {
            val name = URLUtil.guessFileName(c.url, null, c.mime)
            val req = DownloadManager.Request(Uri.parse(c.url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                .addRequestHeader("User-Agent", SourceFinder.UA)
                .addRequestHeader("Referer", referer)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Downloading $name to your Downloads folder")
        } catch (e: Exception) {
            toast("Download failed: ${e.message}")
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("No app can open this link")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
