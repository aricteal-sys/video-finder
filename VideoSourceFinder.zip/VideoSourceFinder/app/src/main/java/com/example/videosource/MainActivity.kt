package com.example.videosource

import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.format.Formatter
import android.view.View
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var engineStatus: TextView
    private lateinit var thumb: ImageView
    private lateinit var infoText: TextView
    private lateinit var engineBox: LinearLayout
    private lateinit var searchBox: LinearLayout
    private lateinit var header: TextView
    private lateinit var results: LinearLayout

    private val ui = Handler(Looper.getMainLooper())
    private var currentUrl = ""
    private var downloading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        engineStatus = findViewById(R.id.engineStatus)
        thumb = findViewById(R.id.thumb)
        infoText = findViewById(R.id.infoText)
        engineBox = findViewById(R.id.engineBox)
        searchBox = findViewById(R.id.searchBox)
        header = findViewById(R.id.header)
        results = findViewById(R.id.results)

        findViewById<Button>(R.id.findBtn).setOnClickListener { start(urlInput.text.toString()) }
        findViewById<Button>(R.id.pasteBtn).setOnClickListener { paste() }
        findViewById<Button>(R.id.updateBtn).setOnClickListener { updateEngine() }
        findViewById<Button>(R.id.bestBtn).setOnClickListener { engineDownload(Engine.FMT_BEST, false) }
        findViewById<Button>(R.id.p720Btn).setOnClickListener { engineDownload(Engine.FMT_720, false) }
        findViewById<Button>(R.id.audioBtn).setOnClickListener { engineDownload(Engine.FMT_AUDIO, true) }

        initEngine()
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    // ---------------------------------------------------------------- engine

    private fun initEngine() {
        engineStatus.text = "Engine: starting (first launch takes a few seconds)…"
        thread {
            Engine.ensureInit(application)
            val prefs = getSharedPreferences("engine", MODE_PRIVATE)
            val due = System.currentTimeMillis() - prefs.getLong("lastUpdate", 0L) > 24L * 3600L * 1000L
            runOnUiThread {
                engineStatus.text = if (Engine.ready) {
                    if (due) "Engine: ready (checking for updates…)" else "Engine: ready"
                } else {
                    "Engine unavailable (${Engine.initError}). Basic page scanning still works."
                }
            }
            if (Engine.ready && due) {
                val msg = Engine.update(application)
                prefs.edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
                runOnUiThread { engineStatus.text = "Engine: ready. $msg" }
            }
        }
    }

    private fun updateEngine() {
        engineStatus.text = "Engine: checking for updates…"
        thread {
            val msg = Engine.update(application)
            runOnUiThread { engineStatus.text = "Engine: $msg" }
        }
    }

    // ----------------------------------------------------------------- input

    private fun handleShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            extractUrl(text)?.let { urlInput.setText(it); start(it) }
        }
    }

    private fun paste() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        urlInput.setText(extractUrl(t) ?: t)
    }

    private fun extractUrl(text: String): String? {
        Regex("""https?://\S+""").find(text)?.value
            ?.trimEnd('.', ',', ')', ']', '"', '\'')
            ?.let { return it }
        val t = text.trim()
        return if (t.contains('.') && !t.contains(' ')) "https://$t" else null
    }

    // ---------------------------------------------------------------- search

    private fun start(raw: String) {
        val url = extractUrl(raw)
        if (url == null) {
            status.text = "Enter a link that starts with http:// or https://"
            return
        }
        currentUrl = url
        results.removeAllViews()
        header.visibility = View.GONE
        searchBox.visibility = View.GONE
        engineBox.visibility = View.GONE
        thumb.visibility = View.GONE
        infoText.visibility = View.GONE
        progress.visibility = View.VISIBLE
        status.text = "Looking for the real source… (can take up to 30 seconds)"

        thread {
            val eng = runCatching { Engine.info(application, url) }
            val first = eng.getOrNull()
            val engineErr = eng.exceptionOrNull()?.let { Engine.friendly(it) }

            val needGeneric = first == null || first.candidates.none { it.kind != Kind.PAGE }
            val gen = if (needGeneric) runCatching { SourceFinder.resolve(url) } else null
            val genInfo = gen?.getOrNull()

            val merged: SourceInfo? = when {
                first == null -> genInfo
                genInfo == null -> first
                else -> first.copy(
                    candidates = first.candidates +
                        genInfo.candidates.filter { c -> first.candidates.none { it.url == c.url } }
                )
            }
            val failText = engineErr ?: gen?.exceptionOrNull()?.message

            runOnUiThread {
                progress.visibility = View.GONE
                if (merged != null) show(merged, engineErr)
                else status.text = "Couldn't read that link: ${failText ?: "unknown error"}"
            }
        }
    }

    private fun show(info: SourceInfo, engineErr: String?) {
        val files = info.candidates.count { it.kind == Kind.FILE }
        val streams = info.candidates.count { it.kind == Kind.STREAM }
        status.text = when {
            info.engine && files > 0 -> "Found $files direct link(s). Use Best / 720p / Audio below for a finished file."
            files > 0 -> "Found $files downloadable file(s)."
            streams > 0 -> "Found a stream playlist but no single file. The engine buttons (if shown) can download it."
            else -> "No downloadable video found." +
                (engineErr?.let { "\n\nEngine said: $it" } ?: "") +
                "\n\nThe site may need a login, use DRM, or block apps. See the README."
        }

        infoText.text = buildString {
            info.title?.let { appendLine(it) }
            val meta = listOfNotNull(info.site?.let { "Site: $it" }, info.author?.let { "Author: $it" })
            if (meta.isNotEmpty()) appendLine(meta.joinToString("  |  "))
            info.details.forEach { appendLine(it) }
            append("Page: ${info.pageUrl}")
        }
        infoText.visibility = View.VISIBLE

        engineBox.visibility = if (info.engine) View.VISIBLE else View.GONE

        info.thumbnail?.let { t ->
            searchBox.visibility = View.VISIBLE
            bind(R.id.lensBtn, "https://lens.google.com/uploadbyurl?url=${Uri.encode(t)}")
            bind(R.id.tineyeBtn, "https://tineye.com/search?url=${Uri.encode(t)}")
            bind(R.id.yandexBtn, "https://yandex.com/images/search?rpt=imageview&url=${Uri.encode(t)}")
            loadThumb(t, info.pageUrl)
        }

        if (info.candidates.isNotEmpty()) header.visibility = View.VISIBLE
        info.candidates.forEach { c ->
            val row = layoutInflater.inflate(R.layout.item_candidate, results, false)
            row.findViewById<TextView>(R.id.label).text = buildString {
                append(c.note ?: c.kind.label)
                c.size?.let { append(" • ").append(Formatter.formatShortFileSize(this@MainActivity, it)) }
                c.mime?.let { append(" • ").append(it) }
            }
            row.findViewById<TextView>(R.id.urlText).text = c.url
            row.findViewById<Button>(R.id.dlBtn).apply {
                visibility = if (c.kind == Kind.FILE && c.standalone) View.VISIBLE else View.GONE
                setOnClickListener { download(c, info) }
            }
            row.findViewById<Button>(R.id.copyBtn).setOnClickListener {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("url", c.url))
                toast("Link copied")
            }
            row.findViewById<Button>(R.id.openBtn).setOnClickListener { openUrl(c.url) }
            results.addView(row)
        }
    }

    private fun bind(id: Int, url: String) {
        findViewById<Button>(id).setOnClickListener { openUrl(url) }
    }

    private fun loadThumb(url: String, referer: String) {
        thread {
            val bytes = SourceFinder.fetchBytes(url, referer) ?: return@thread
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@thread
            runOnUiThread {
                thumb.setImageBitmap(bmp)
                thumb.visibility = View.VISIBLE
            }
        }
    }

    // ------------------------------------------------------------- downloads

    /** Quick download of one direct link through Android's download manager. */
    private fun download(c: Candidate, info: SourceInfo) {
        try {
            val name = fileNameFor(c, info)
            val req = DownloadManager.Request(Uri.parse(c.url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)

            val ua = c.headers.entries.firstOrNull { it.key.equals("User-Agent", true) }?.value
                ?: SourceFinder.UA
            req.addRequestHeader("User-Agent", ua)
            c.headers.forEach { (k, v) ->
                if (!k.equals("User-Agent", true) && !k.equals("Accept-Encoding", true)) {
                    req.addRequestHeader(k, v)
                }
            }
            if (c.headers.keys.none { it.equals("Referer", true) }) {
                req.addRequestHeader("Referer", info.pageUrl)
            }

            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Downloading $name to your Downloads folder")
        } catch (e: Exception) {
            toast("Download failed: ${e.message}")
        }
    }

    private fun fileNameFor(c: Candidate, info: SourceInfo): String {
        val ext = c.ext
        if (ext.isNullOrBlank()) return URLUtil.guessFileName(c.url, null, c.mime)
        val base = (info.title ?: "video").replace(Regex("[^A-Za-z0-9._ -]"), "_")
            .trim().take(60).ifBlank { "video" }
        return "$base.$ext"
    }

    /** Full download with yt-dlp: picks and merges the best streams, then saves to Downloads/VideoSource. */
    private fun engineDownload(format: String, audioOnly: Boolean) {
        if (downloading || currentUrl.isEmpty()) return
        downloading = true
        setEngineButtons(false)
        progress.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val dir = File(getExternalFilesDir(null) ?: filesDir, "dl-${System.currentTimeMillis()}")
        val running = AtomicBoolean(true)
        val poll = object : Runnable {
            override fun run() {
                if (!running.get()) return
                val size = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
                status.text = "Downloading… ${Formatter.formatShortFileSize(this@MainActivity, size)} " +
                    "(keep the app open)"
                ui.postDelayed(this, 1000)
            }
        }
        status.text = "Starting download…"
        ui.post(poll)

        val url = currentUrl
        thread {
            val saved = runCatching {
                val f = Engine.download(application, url, format, dir, audioOnly)
                saveToDownloads(f) ?: error("Couldn't save the file to Downloads")
                f.name
            }
            running.set(false)
            dir.deleteRecursively()
            runOnUiThread {
                downloading = false
                setEngineButtons(true)
                progress.visibility = View.GONE
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                saved.onSuccess {
                    status.text = "Saved: Downloads/VideoSource/$it"
                    toast("Saved to Downloads/VideoSource")
                }.onFailure {
                    status.text = "Download failed: ${Engine.friendly(it)}"
                }
            }
        }
    }

    private fun setEngineButtons(enabled: Boolean) {
        listOf(R.id.bestBtn, R.id.p720Btn, R.id.audioBtn).forEach { findViewById<Button>(it).isEnabled = enabled }
    }

    private fun saveToDownloads(f: File): Uri? {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase())
            ?: "application/octet-stream"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VideoSource")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { out ->
            f.inputStream().use { it.copyTo(out) }
        }
        return uri
    }

    // ----------------------------------------------------------------- misc

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("No app can open this link")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
