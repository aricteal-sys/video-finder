# Video Source Finder (Android) v2

Paste a link, or share one to the app from your browser, and it finds where the video really lives.

## How it works
1. **yt-dlp engine** (free, open source, bundled): resolves the real media address on well over a
   thousand sites (YouTube, TikTok, Instagram, Facebook, X, Reddit, Vimeo, news sites and more)
   plus a generic extractor for ordinary pages. It lists direct file links, the resolved original
   page, uploader/channel page, date, and thumbnail.
2. **Page scanner** (fallback): reads og:video tags, <video> tags, JSON-LD, player config and
   embedded players when the engine finds nothing.
3. **Download**: Best / 720p / Audio buttons merge the best video + audio and save the file to
   Downloads/VideoSource. Single direct links can also be downloaded with the Download button.
4. **Trace the uploader**: reverse-search the thumbnail with Google Lens, TinEye and Yandex.

Sites change often, so the app checks for a newer yt-dlp once a day. You can also tap
"Update engine". Updates are free.

## Build the APK (GitHub Actions)
1. Put VideoSourceFinder.zip in your repo (uploading a file with the same name replaces the old one)
   together with `.github/workflows/build.yml`.
2. Actions tab > run "Build APK" > download artifact `VideoSourceFinder-debug-apk`.
3. Unzip it and install `app-debug.apk`. The first build downloads the engine libraries and takes
   longer. The APK is large (about 100 MB or more) because it contains Python and ffmpeg.
   To shrink it, delete one ABI in `app/build.gradle.kts` (abiFilters).

Or open the folder in Android Studio and choose Build > Build APK(s).

## Limits (read this)
- No tool can promise "any website". yt-dlp does not work on DRM-protected services (Netflix, Disney+,
  Prime Video, Spotify and similar), pages behind a login, or sites that block apps. The app does not
  bypass DRM, logins or paywalls.
- Keep the app open during a download. Long downloads in the background can be stopped by Android.
- Reverse search uses the thumbnail, so it finds copies of the preview image. That is a strong lead
  to the original uploader, not proof.
- Only download videos you own or have permission to save.
- The yt-dlp library used here is GPL-3.0. Fine for personal use. If you share the APK with others,
  you must also share this source code.
- This project was written without being compiled in the authoring environment. If the build
  reports an error, copy the error text and it can be fixed quickly.
