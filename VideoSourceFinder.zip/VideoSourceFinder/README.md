# Video Source Finder (Android)

Paste a link, or share one to the app from your browser, and it reports where the video really lives:

- follows redirects and short links
- reads the page's public code for the real video file (og:video, <video> tags, JSON-LD, player config)
- looks inside embedded players one level deep
- shows the site's canonical (declared original) page, author and thumbnail
- downloads direct files through Android's download manager (Downloads folder)
- sends the thumbnail to Google Lens, TinEye and Yandex to trace the first uploader of re-posted clips

## Build the APK

**Option A, no install (GitHub Actions)**
1. Create a free GitHub repo and upload this whole folder (keep the folder structure, including `.github/workflows/build.yml`).
2. Open the repo's Actions tab, run "Build APK" (it also runs on every push).
3. When it finishes, download the artifact `VideoSourceFinder-debug-apk`, unzip it, install `app-debug.apk`.
   Android will ask you to allow installs from your browser or file manager.

**Option B, Android Studio**
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

**Option C, from a terminal with git (for example Termux)**
    pkg install git unzip
    unzip VideoSourceFinder.zip && cd VideoSourceFinder
    git init && git add . && git commit -m "init"
    git remote add origin https://github.com/YOURNAME/YOURREPO.git
    git push -u origin master   # use a GitHub personal access token as the password

## Use
Paste a link and tap Find source, or use Share > Video Source Finder from another app.
Each result row has Download (direct files only), Copy link and Open.

## Limits (read this)
- It only uses what a site publicly serves. YouTube, TikTok, Instagram, Facebook, Netflix and similar
  use signed, expiring or protected streams, so for them it will show the page but usually no file.
  A site-specific extractor such as yt-dlp is needed there.
- .m3u8 / .mpd results are playlists, not single files. Copy the link into yt-dlp or ffmpeg.
- The app does not bypass logins, DRM or paywalls.
- Reverse search works on the page's thumbnail, so it finds copies of the preview image,
  which is usually the best lead to the original uploader but not proof.
- Only download videos you own or have permission to save.
- This project was written without being compiled in the authoring environment. If the first build
  reports an error, copy the error text and it can be fixed quickly.
